/* 
<?php
require(dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-config.php');
header("content-type: application/x-javascript");
?> 
*/

var clear = 'assets/images/clear.gif';

var imgLoading = 'assets/images/lightbox/loading.gif';
var imgClose = 'assets/images/lightbox/closelabel.gif';

var videoWidth = 300;
var videoHeight = 225;
var youtubeID = 'FpAgUMUlhw4';

var searchDefault = 'Search this website...';
var searchColor = '#000000';

var adsenseID = '8716859555418928';
